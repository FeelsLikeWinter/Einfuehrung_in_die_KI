import pandas as pd
import numpy as np
import re
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, confusion_matrix

df = pd.read_csv("spam_ham_dataset.csv")

print(df.head())
print(df.columns)

df["label"] = df["label"].map({"ham": 0, "spam": 1})

# Sonderzeichen entfernen und Text kleinschreiben 
def clean_text(text):
    text = text.lower()
    text = re.sub(r"[^a-zäöüß ]", "", text)
    return text


df["text_clean"] = df["text"].apply(clean_text)

vectorizer = CountVectorizer(
    stop_words="english",   # Ignoriert standardwörter wie "the"
    min_df=2                # Wörter die nur 1 mal vorkommen ignorieren
)

X = vectorizer.fit_transform(df["text_clean"])
y = df["label"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

model = MultinomialNB()
model.fit(X_train, y_train)

y_pred = model.predict(X_test)

print("Accuracy:", accuracy_score(y_test, y_pred))
print("\nConfusion Matrix:\n", confusion_matrix(y_test, y_pred))

feature_names = vectorizer.get_feature_names_out()

# Top Spam und Ham
spam_log_probs = model.feature_log_prob_[1]
ham_log_probs = model.feature_log_prob_[0]

diff = spam_log_probs - ham_log_probs

top_spam = np.argsort(diff)[-10:]
top_ham = np.argsort(diff)[:10]

print("Spam:")
for i in reversed(top_spam):
    print(feature_names[i])

print("\nHam:")
for i in top_ham:
    print(feature_names[i])
